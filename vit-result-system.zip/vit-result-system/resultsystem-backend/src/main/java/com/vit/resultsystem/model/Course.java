package com.vit.resultsystem.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;

@Entity
public class Course {

    @Id
    private String courseId;   // e.g., "CSE2001"

    private String title;      // e.g., "Data Structures & Algorithms"

    @OneToMany(mappedBy = "course")
    @JsonIgnore
    private List<Result> results;

    // Getters & Setters
    public String getCourseId() {
        return courseId;
    }
    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }

    public List<Result> getResults() {
        return results;
    }
    public void setResults(List<Result> results) {
        this.results = results;
    }
}
