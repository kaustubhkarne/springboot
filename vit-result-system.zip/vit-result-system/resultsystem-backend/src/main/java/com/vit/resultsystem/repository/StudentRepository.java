package com.vit.resultsystem.repository;

import com.vit.resultsystem.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, String> {
    // String because Student.id is a String (like 21BCE0001)
}
