package com.vit.resultsystem.repository;

import com.vit.resultsystem.model.Result;
import com.vit.resultsystem.model.Student;
import com.vit.resultsystem.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ResultRepository extends JpaRepository<Result, Long> {
    List<Result> findByStudent(Student student);
    Optional<Result> findByStudentAndCourse(Student student, Course course);
}
