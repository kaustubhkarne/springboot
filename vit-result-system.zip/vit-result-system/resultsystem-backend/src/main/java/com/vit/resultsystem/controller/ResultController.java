package com.vit.resultsystem.controller;

import com.vit.resultsystem.model.Result;
import com.vit.resultsystem.model.Student;
import com.vit.resultsystem.model.Course;
import com.vit.resultsystem.repository.ResultRepository;
import com.vit.resultsystem.repository.StudentRepository;
import com.vit.resultsystem.repository.CourseRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/results")
public class ResultController {

    private final ResultRepository resultRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;

    public ResultController(ResultRepository resultRepository,
                            StudentRepository studentRepository,
                            CourseRepository courseRepository) {
        this.resultRepository = resultRepository;
        this.studentRepository = studentRepository;
        this.courseRepository = courseRepository;
    }

    // 🔹 Get all results
    @GetMapping
    public List<Result> getAllResults() {
        return resultRepository.findAll();
    }

    // 🔹 Get results by studentId
    @GetMapping("/student/{studentId}")
    public List<Result> getResultsByStudent(@PathVariable String studentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        return resultRepository.findByStudent(student);
    }

    // 🔹 Add result (creates student if not present)
    @PostMapping
    public ResponseEntity<Result> addResult(@RequestBody Result incomingResult) {
        // ✅ Ensure student exists
        Student student = studentRepository.findById(incomingResult.getStudent().getStudentId())
                .orElseGet(() -> {
                    Student s = new Student();
                    s.setStudentId(incomingResult.getStudent().getStudentId());
                    s.setName(incomingResult.getStudent().getName());
                    return studentRepository.save(s);
                });

        // ✅ Ensure course exists
        Course course = courseRepository.findById(incomingResult.getCourse().getCourseId())
                .orElseThrow(() -> new RuntimeException("Course not found"));

        // ✅ Create new result
        Result result = new Result();
        result.setStudent(student);
        result.setCourse(course);
        result.setMse(incomingResult.getMse());
        result.setEse(incomingResult.getEse());

        int total = incomingResult.getMse() + incomingResult.getEse();
        result.setTotal(total);

        // Grade logic
        if (total >= 90) result.setGrade("A+");
        else if (total >= 80) result.setGrade("A");
        else if (total >= 70) result.setGrade("B+");
        else if (total >= 60) result.setGrade("B");
        else if (total >= 50) result.setGrade("C");
        else if (total >= 40) result.setGrade("D");
        else result.setGrade("F");

        result.setSemester(incomingResult.getSemester());
        result.setCgpa(total / 10.0);

        return ResponseEntity.ok(resultRepository.save(result));
    }
}
