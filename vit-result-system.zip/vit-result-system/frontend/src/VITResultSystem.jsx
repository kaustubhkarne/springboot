import React, { useState, useEffect } from 'react';
import axios from "axios";
import { Search, BookOpen, User, Calendar, Trophy } from 'lucide-react';

const VITResultSystem = () => {
  const [students, setStudents] = useState([]);
  const [courses, setCourses] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showForm, setShowForm] = useState(false);

  const [form, setForm] = useState({
    studentId: "",
    name: "",
    semester: "",
    courseId: "",
    mse: "",
    ese: ""
  });

  // Fetch students
  useEffect(() => {
    axios.get("http://localhost:8080/api/students")
      .then(res => setStudents(res.data))
      .catch(err => console.error("Error fetching students:", err));
  }, []);

  // Fetch courses
  useEffect(() => {
    axios.get("http://localhost:8080/api/courses")
      .then(res => setCourses(res.data))
      .catch(err => console.error("Error fetching courses:", err));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:8080/api/results", {
        student: { studentId: form.studentId, name: form.name },
        course: { courseId: form.courseId },
        mse: parseInt(form.mse),
        ese: parseInt(form.ese),
        semester: form.semester
      });

      alert("✅ Result added successfully");

      const updated = await axios.get("http://localhost:8080/api/students");
      setStudents(updated.data);

      setForm({ studentId: "", name: "", semester: "", courseId: "", mse: "", ese: "" });
      setShowForm(false);
    } catch (error) {
      console.error("Error adding result:", error);
      alert("❌ Failed to add result");
    }
  };

  const filteredStudents = students.filter(student =>
    student.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.studentId?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-purple-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-3 rounded-xl">
                <BookOpen className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">VIT University</h1>
                <p className="text-gray-600">Student Result Management System</p>
              </div>
            </div>

            {/* Toggle Add Result Form */}
            <button
              onClick={() => setShowForm(!showForm)}
              className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-2 rounded-lg hover:from-purple-700 hover:to-indigo-700"
            >
              {showForm ? "Close Form" : "➕ Add Result"}
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        {/* Add Result Form */}
        {showForm && (
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
            <h2 className="text-xl font-bold mb-6">Add Student Result</h2>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <input type="text" placeholder="Student ID" value={form.studentId}
                onChange={e => setForm({ ...form, studentId: e.target.value })} required />
              <input type="text" placeholder="Name" value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })} required />
              <input type="text" placeholder="Semester" value={form.semester}
                onChange={e => setForm({ ...form, semester: e.target.value })} required />

              <select value={form.courseId} onChange={e => setForm({ ...form, courseId: e.target.value })} required>
                <option value="">Select Course</option>
                {courses.map(c => (
                  <option key={c.courseId} value={c.courseId}>{c.title} ({c.courseId})</option>
                ))}
              </select>

              <input type="number" placeholder="MSE" value={form.mse}
                onChange={e => setForm({ ...form, mse: e.target.value })} required />
              <input type="number" placeholder="ESE" value={form.ese}
                onChange={e => setForm({ ...form, ese: e.target.value })} required />

              <button type="submit"
                className="md:col-span-2 w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-2 rounded-lg">
                Save Result
              </button>
            </form>
          </div>
        )}

        {/* Tabs */}
        <div className="flex space-x-1 bg-white p-1 rounded-xl shadow-md mb-8">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Trophy },
            { id: 'students', label: 'Student Results', icon: User },
            { id: 'analytics', label: 'Analytics', icon: BookOpen }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex items-center justify-center py-3 px-6 rounded-lg ${activeTab === tab.id
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white'
                  : 'text-gray-600 hover:text-purple-600 hover:bg-purple-50'}`}>
                <Icon className="h-5 w-5" /><span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Student Results */}
        {activeTab === 'students' && (
          <div className="space-y-6">
            {filteredStudents.map(s => (
              <div key={s.studentId} className="bg-white rounded-2xl shadow-lg p-6">
                <h2 className="text-xl font-bold mb-2">{s.name} ({s.studentId})</h2>
                <p className="mb-4">Semester: {s.results?.[0]?.semester || "N/A"}</p>
                <table className="w-full border">
                  <thead>
                    <tr className="bg-gray-100">
                      <th>Subject</th><th>Code</th><th>MSE</th><th>ESE</th><th>Total</th><th>Grade</th>
                    </tr>
                  </thead>
                  <tbody>
                    {s.results?.map(r => (
                      <tr key={r.id}>
                        <td>{r.course?.title}</td>
                        <td>{r.course?.courseId}</td>
                        <td>{r.mse}</td>
                        <td>{r.ese}</td>
                        <td>{r.total}</td>
                        <td>{r.grade}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default VITResultSystem;
