package com.vit.results.controller;

import com.vit.results.model.Course;
import com.vit.results.model.Marks;
import com.vit.results.model.Student;
import com.vit.results.repository.CourseRepository;
import com.vit.results.repository.MarksRepository;
import com.vit.results.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity; // Import for ResponseEntity
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:3000")
public class ResultController {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private MarksRepository marksRepository;

    @Autowired
    private CourseRepository courseRepository;

    // --- EXISTING GET ENDPOINTS ---

    @GetMapping("/student/{studentId}")
    public Optional<Student> getStudent(@PathVariable String studentId) {
        return studentRepository.findById(studentId);
    }

    @GetMapping("/courses")
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    @GetMapping("/marks/{studentId}")
    public List<Marks> getMarksByStudentId(@PathVariable String studentId) {
        return marksRepository.findAll().stream()
                .filter(marks -> marks.getId().getStudentId().equals(studentId))
                .collect(Collectors.toList());
    }

    // --- NEW POST ENDPOINT FOR ADDING STUDENTS ---

    @PostMapping("/addResult")
    public ResponseEntity<String> addStudentResult(@RequestBody List<Marks> marksList) {
        if (marksList == null || marksList.isEmpty()) {
            return ResponseEntity.badRequest().body("Marks list cannot be empty.");
        }

        // Assume the first Mark object contains the studentId we need
        String studentId = marksList.get(0).getId().getStudentId();

        // Check if student exists (assuming Student model has been populated elsewhere)
        if (!studentRepository.existsById(studentId)) {
            return ResponseEntity.badRequest().body("Student ID not found. Please add student first or ensure ID is correct.");
        }

        try {
            // Save all mark entries
            marksRepository.saveAll(marksList);
            return ResponseEntity.ok("Successfully added marks for student: " + studentId);
        } catch (Exception e) {
            // Log the exception for debugging
            System.err.println("Error saving marks: " + e.getMessage());
            return ResponseEntity.status(500).body("Failed to save results due to a database error.");
        }
    }
}