package com.vit.results.model;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;
import java.io.Serializable;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Entity
@Table(name = "marks")
@Data
public class Marks {
    @EmbeddedId
    private MarksId id;
    private int mse;
    private int ese;

    @Embeddable
    @Data
    public static class MarksId implements Serializable {
        @Column(name = "student_id")
        private String studentId;

        @Column(name = "course_id")
        private String courseId;
    }
}