package com.vit.results;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VitResultsApplication {

    public static void main(String[] args) {
        SpringApplication.run(VitResultsApplication.class, args);
    }
}