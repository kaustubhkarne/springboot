// frontend/src/App.js
import React, { useState } from 'react';
import ResultTable from './components/ResultTable';
import AddResultForm from './components/AddResultForm'; // NEW IMPORT
import './index.css';

function App() {
    const [inputID, setInputID] = useState('1'); 
    const [currentID, setCurrentID] = useState('1'); 
    const [view, setView] = useState('search'); // State to toggle views ('search' or 'add')

    const handleSearch = () => {
        setCurrentID(inputID.trim());
        setView('search');
    };
    
    return (
        <div className="App">
            <div className="container" style={{textAlign: 'center'}}>
                {/* NAVIGATION BUTTONS */}
                <button 
                    onClick={() => setView('search')}
                    style={{ padding: '10px 15px', marginRight: '10px', backgroundColor: view === 'search' ? '#004a99' : '#ccc', color: view === 'search' ? 'white' : 'black', border: 'none', borderRadius: '5px', cursor: 'pointer' }}
                >
                    View Results
                </button>
                <button 
                    onClick={() => setView('add')}
                    style={{ padding: '10px 15px', backgroundColor: view === 'add' ? '#004a99' : '#ccc', color: view === 'add' ? 'white' : 'black', border: 'none', borderRadius: '5px', cursor: 'pointer' }}
                >
                    Add Results
                </button>
            </div>

            {/* CONDITIONAL RENDERING */}
            {view === 'search' ? (
                <>
                    <div className="container search-bar">
                        <h2>Search Student Result</h2>
                        <input
                            type="text"
                            placeholder="Enter Student ID (e.g., 1 or 2)"
                            value={inputID}
                            onChange={(e) => setInputID(e.target.value)}
                            style={{ padding: '10px', marginRight: '10px', width: '200px', borderRadius: '5px', border: '1px solid #ccc' }}
                        />
                        <button 
                            onClick={handleSearch}
                            style={{ padding: '10px 15px', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}
                        >
                            Get Result
                        </button>
                    </div>
                    <ResultTable studentId={currentID} />
                </>
            ) : (
                <AddResultForm />
            )}
        </div>
    );
}

export default App;