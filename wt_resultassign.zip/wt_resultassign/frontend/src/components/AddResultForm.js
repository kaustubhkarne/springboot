// frontend/src/components/AddResultForm.js
import React, { useState, useEffect } from 'react';

const BASE_URL = 'http://localhost:8080/api';

const AddResultForm = () => {
    const [courses, setCourses] = useState([]);
    const [studentId, setStudentId] = useState('');
    const [name, setName] = useState('');
    const [marks, setMarks] = useState({});
    const [message, setMessage] = useState(null);
    const [isError, setIsError] = useState(false);

    // 1. Fetch available courses on load
    useEffect(() => {
        fetch(`${BASE_URL}/courses`)
            .then(res => res.json())
            .then(data => setCourses(data))
            .catch(err => {
                setMessage("Could not fetch courses. Check backend.");
                setIsError(true);
            });
    }, []);

    // 2. Handle input changes for MSE/ESE marks
    const handleMarkChange = (courseId, type, value) => {
        setMarks(prev => ({
            ...prev,
            [courseId]: {
                ...prev[courseId],
                [type]: parseInt(value) || 0,
            }
        }));
    };

    // 3. Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage(null);
        setIsError(false);

        // --- Step 3a: Prepare Marks Data Structure ---
        const marksList = courses.map(course => {
            const courseMarks = marks[course.courseId] || {};
            return {
                id: {
                    studentId: studentId.trim(),
                    courseId: course.courseId
                },
                mse: courseMarks.mse || 0,
                ese: courseMarks.ese || 0,
            };
        });

        // --- Step 3b: Send POST Request ---
        try {
            const response = await fetch(`${BASE_URL}/addResult`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': 'http://localhost:3000'
                },
                body: JSON.stringify(marksList)
            });

            const text = await response.text();
            
            if (response.ok) {
                setMessage(`Success: ${text}. Refresh the result search page to view.`);
            } else {
                setIsError(true);
                setMessage(`Error: ${text}`);
            }

        } catch (error) {
            setIsError(true);
            setMessage("Network Error: Could not connect to the API server.");
            console.error(error);
        }
    };
    
    // NOTE: This form assumes the student entry already exists in the 'student' table.
    // A complete solution would require a separate POST endpoint to add the new Student (ID and Name) first.
    return (
        <div className="container" style={{maxWidth: '600px'}}>
            <h2>Add New Student Results</h2>
            
            {message && (
                <div style={{ padding: '10px', backgroundColor: isError ? '#f8d7da' : '#d4edda', color: isError ? '#721c24' : '#155724', borderRadius: '5px', marginBottom: '15px' }}>
                    {message}
                </div>
            )}

            <form onSubmit={handleSubmit}>
                <div style={{ marginBottom: '15px' }}>
                    <label style={{ display: 'block', marginBottom: '5px' }}>Student ID (Must Exist in DB):</label>
                    <input 
                        type="text" 
                        value={studentId} 
                        onChange={(e) => setStudentId(e.target.value)}
                        required
                        style={{ padding: '8px', width: '90%' }}
                    />
                </div>
                
                <table className="results-table">
                    <thead>
                        <tr>
                            <th>Course Code</th>
                            <th>MSE (Max 30)</th>
                            <th>ESE (Max 70)</th>
                        </tr>
                    </thead>
                    <tbody>
                        {courses.map(course => (
                            <tr key={course.courseId}>
                                <td>{course.courseId} - {course.courseTitle}</td>
                                <td>
                                    <input
                                        type="number"
                                        min="0"
                                        max="30"
                                        value={marks[course.courseId]?.mse || ''}
                                        onChange={(e) => handleMarkChange(course.courseId, 'mse', e.target.value)}
                                        style={{ width: '60px', textAlign: 'center' }}
                                    />
                                </td>
                                <td>
                                    <input
                                        type="number"
                                        min="0"
                                        max="70"
                                        value={marks[course.courseId]?.ese || ''}
                                        onChange={(e) => handleMarkChange(course.courseId, 'ese', e.target.value)}
                                        style={{ width: '60px', textAlign: 'center' }}
                                    />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                
                <button type="submit" style={{ padding: '10px 20px', marginTop: '20px', backgroundColor: '#004a99', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>
                    Save Results
                </button>
            </form>
        </div>
    );
};

export default AddResultForm;