import React, { useState, useEffect } from 'react';
// import axios from 'axios';  <-- REMOVED AXIOS IMPORT

const BASE_URL = 'http://localhost:8080/api';

const ResultTable = ({ studentId }) => {
    const [student, setStudent] = useState(null);
    const [marks, setMarks] = useState([]);
    const [courses, setCourses] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchResults = async () => {
            setLoading(true);
            setError(null);
            try {
                // 1. Fetch student info using native fetch
                const studentResponse = await fetch(`${BASE_URL}/student/${studentId}`);
                const studentData = await studentResponse.json();

                if (studentData && studentData.studentId) {
                    setStudent(studentData);
                } else {
                    setError(`Student with ID ${studentId} not found.`);
                    setLoading(false);
                    return;
                }

                // 2. Fetch marks and courses concurrently using Promise.all with fetch
                const [marksResponse, coursesResponse] = await Promise.all([
                    fetch(`${BASE_URL}/marks/${studentId}`),
                    fetch(`${BASE_URL}/courses`)
                ]);
                
                // Parse JSON data from responses
                const marksData = await marksResponse.json();
                const coursesData = await coursesResponse.json();

                setMarks(marksData);
                setCourses(coursesData);
                
            } catch (err) {
                console.error("API Fetch Error:", err);
                // Provide specific instructions in the error message
                setError("Failed to connect to server or retrieve data. Ensure the backend server is running on port 8080.");
            } finally {
                setLoading(false);
            }
        };

        if (studentId) {
            fetchResults();
        }
    }, [studentId]);

    // Function to calculate final marks: MSE (30%) + ESE (70%)
    const calculateTotal = (mse, ese) => {
        return (mse) + (ese); 
    };

    if (loading) return <div className="container">Loading results...</div>;
    if (error) return <div className="container" style={{ color: 'red' }}>Error: {error}</div>;
    if (!student) return <div className="container">Please enter a valid Student ID.</div>;

    const courseMap = new Map(courses.map(c => [c.courseId, c.courseTitle]));

    return (
        <div className="container">
            <h1>VIT Semester Result</h1>
            
            <div className="student-info">
                <p><strong>Name:</strong> {student.name}</p>
                <p><strong>Student ID:</strong> {student.studentId}</p>
                <p><strong>Semester:</strong> V</p> 
            </div>
            
            <table className="results-table">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Course Title</th>
                        <th>MSE (30%)</th>
                        <th>ESE (70%)</th>
                        <th>Total (100)</th>
                    </tr>
                </thead>
                <tbody>
                    {marks.map(mark => {
                        const totalMarks = calculateTotal(mark.mse, mark.ese);
                        return (
                            <tr key={mark.id.courseId}>
                                <td>{mark.id.courseId}</td>
                                <td>{courseMap.get(mark.id.courseId) || 'Course Not Found'}</td>
                                <td>{mark.mse}</td>
                                <td>{mark.ese}</td>
                                <td className={totalMarks < 40 ? 'fail-grade' : ''}>{totalMarks.toFixed(0)}</td>
                            </tr>
                        );
                    })}
                    {marks.length === 0 && (
                        <tr>
                            <td colSpan="5">No marks found for this student.</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
};

export default ResultTable;